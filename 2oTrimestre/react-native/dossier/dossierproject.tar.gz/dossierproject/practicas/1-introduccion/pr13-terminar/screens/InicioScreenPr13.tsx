import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import PruebaPrompt from '../components/PruebaPrompt'

type Props = {}

const InicioScreenPr13 = (props: Props) => {
    return (
        <View>
            <PruebaPrompt/>
        </View>
    )
}

export default InicioScreenPr13

const styles = StyleSheet.create({})