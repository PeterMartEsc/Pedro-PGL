import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import CambiarColor from '../components/CambiarColor'

type Props = {}

const InicioScreenPr12 = (props: Props) => {
    return (
        <View>
            <CambiarColor/>
        </View>
    )
}

export default InicioScreenPr12

const styles = StyleSheet.create({})    