import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import DiarioPr18 from '../components/DiarioPr19'

type Props = {}

const InicioScreenPr19 = (props: Props) => {
    return (
        <View style={{flex:1}}>
            <DiarioPr18/>
        </View>
    )
}

export default InicioScreenPr19

const styles = StyleSheet.create({})