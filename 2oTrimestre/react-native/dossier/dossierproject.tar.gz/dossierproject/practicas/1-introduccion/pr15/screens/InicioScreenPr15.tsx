import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import PruebaFormulario from '../components/PruebaFormulario'

type Props = {}

const InicioScreenPr15 = (props: Props) => {
    return (
        <View>
            <PruebaFormulario/>
        </View>
    )
}

export default InicioScreenPr15

const styles = StyleSheet.create({})