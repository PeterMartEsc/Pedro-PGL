import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const PrincipalNavigationPr26 = (props: Props) => {
  return (
    <View>
      <Text>PrincipalNavigationPr26</Text>
    </View>
  )
}

export default PrincipalNavigationPr26

const styles = StyleSheet.create({})