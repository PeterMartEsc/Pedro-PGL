import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Pantalla1Screen = (props: Props) => {
  return (
    <View>
      <Text>Pantalla1Screen</Text>
    </View>
  )
}

export default Pantalla1Screen

const styles = StyleSheet.create({})