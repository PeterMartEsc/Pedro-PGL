import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Pantalla2Screen = (props: Props) => {
  return (
    <View>
      <Text>Pantalla2Screen</Text>
    </View>
  )
}

export default Pantalla2Screen

const styles = StyleSheet.create({})