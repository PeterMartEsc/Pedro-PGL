import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const StackNavigation = (props: Props) => {
  return (
    <View>
      <Text>StackNavigation</Text>
    </View>
  )
}

export default StackNavigation

const styles = StyleSheet.create({})