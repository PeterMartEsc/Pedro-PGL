export default class Ejercicio {
    
}